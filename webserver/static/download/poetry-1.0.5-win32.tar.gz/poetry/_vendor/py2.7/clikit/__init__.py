from .api.config.application_config import ApplicationConfig
from .config.default_application_config import DefaultApplicationConfig
from .console_application import ConsoleApplication

__version__ = "0.4.2"
