from .component import Component
from .rectangle import Rectangle
