class ParseVersionError(ValueError):
    pass
